getwd()
setwd("C:\\Users\\IT24103987\\Desktop\\IT24103987")

#Import the dataset and store it in a data frame called”branch data”
branch_data <- read.table("Exercise.txt", header=TRUE, sep="\t")
head(branch_data)

#Identify the variable type and scale of measurement for each variable
str(branch_data)

#boxplot for sales and interpret the shape of the sales distribution
boxplot(branch_data$sales, main="Boxplot of Sales", ylab="Sales",outline=TRUE,outpch=8,horizontal=TRUE)

#Five number summary and IQR for advertising variable
five_num(branch_data$advertising)

IQR(branch_data$advertising)

#Find the outliers in a numeric vector and check for outliers in years variables
find_outliers <- function(x) {
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR_value <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
  
}


outliers_years <- find_outliers(branch_data$years)
outliers_years
